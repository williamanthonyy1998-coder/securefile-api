declare module 'nodemailer';
