import { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { Check, Download, Eye, FileText, FolderOpen, KeyRound, LockKeyhole, LogIn, ShieldCheck, Upload, Pencil, Trash2, Share2 } from "lucide-react";
import { api, API } from "../lib/api";

type ShareData = {
  file?: { id: string; name: string; mimeType?: string } | null;
  folder?: { id: string; name: string } | null;
  permissions?: Record<string, boolean>;
  downloadUrl?: string | null;
  contentUrl?: string | null;
  requiresLogin?: boolean;
  loginUrl?: string | null;
};

function typeLabel(mime = "") {
  if (mime.includes("pdf")) return "PDF document";
  if (mime.startsWith("image/")) return "Image";
  if (mime.includes("word") || mime.includes("document")) return "Document";
  if (mime.includes("sheet") || mime.includes("excel")) return "Spreadsheet";
  if (mime.startsWith("text/")) return "Text file";
  return "Shared file";
}

export default function PublicShare() {
  const { token = "" } = useParams();
  const [password, setPassword] = useState("");
  const [data, setData] = useState<ShareData | null>(null);
  const [contentUrl, setContentUrl] = useState("");
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);
  const [contentLoading, setContentLoading] = useState(false);

  async function unlock() {
    try {
      setLoading(true); setErr("");
      const d = await api(`/public/shares/${encodeURIComponent(token)}/unlock`, { method: "POST", body: JSON.stringify({ password }) });
      setData(d);
    } catch (e: any) { setErr(e.message || "Unable to open this share."); }
    finally { setLoading(false); }
  }

  useEffect(() => {
    if (!data?.contentUrl || !data.permissions?.view) return;
    let cancelled = false;
    (async () => {
      try {
        setContentLoading(true); setErr("");
        const response = await fetch(`${API}/public/shares/${encodeURIComponent(token)}/content`, { headers: password ? { "x-share-password": password } : {} });
        if (!response.ok) throw new Error("Preview is unavailable for this share.");
        const blob = await response.blob();
        const url = URL.createObjectURL(blob);
        if (!cancelled) setContentUrl(url); else URL.revokeObjectURL(url);
      } catch (e: any) { if (!cancelled) setErr(e.message || "Preview is unavailable."); }
      finally { if (!cancelled) setContentLoading(false); }
    })();
    return () => { cancelled = true; };
  }, [data?.contentUrl, data?.permissions?.view, password]);

  useEffect(() => () => { if (contentUrl) URL.revokeObjectURL(contentUrl); }, [contentUrl]);

  async function download() {
    if (!data?.downloadUrl || !data.permissions?.download) return;
    try {
      setErr("");
      const r = await fetch(`${API}/public/shares/${encodeURIComponent(token)}/download`, { headers: password ? { "x-share-password": password } : {} });
      if (!r.ok) {
        const text = await r.text();
        let message = "Download is not permitted for this share.";
        try { message = JSON.parse(text)?.error || message; } catch {}
        throw new Error(message);
      }
      const b = await r.blob();
      const u = URL.createObjectURL(b), a = document.createElement("a");
      a.href = u; a.download = data.file?.name || "download"; document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(u), 1000);
    } catch (e: any) { setErr(e.message || "Download failed."); }
  }

  const permissionItems = useMemo(() => [
    ["view", "View", Eye], ["download", "Download", Download], ["upload", "Upload", Upload],
    ["edit", "Edit", Pencil], ["delete", "Delete", Trash2], ["share", "Share", Share2],
  ] as const, []);

  const file = data?.file;
  const folder = data?.folder;
  const loginHref = data?.loginUrl || `/login?returnTo=/public-share/${encodeURIComponent(token)}`;

  return <div className="public-share-page">
    <div className="public-share-glow" />
    <main className="public-share-card">
      <div className="public-share-brand"><div className="public-share-brand-mark"><ShieldCheck size={19} /></div><span>SecureFile</span><em>PUBLIC SHARE</em></div>
      <div className="public-share-header">
        <div className="public-share-resource-icon">{folder ? <FolderOpen size={24} /> : <FileText size={24} />}</div>
        <div className="public-share-title-wrap">
          <p className="eyebrow">{folder ? "Shared folder" : "Shared file"}</p>
          <h1 title={file?.name || folder?.name}>{file?.name || folder?.name || "Shared resource"}</h1>
          {file?.mimeType && <p className="public-share-type">{typeLabel(file.mimeType)} · Secure access</p>}
        </div>
      </div>

      {!data && <section className="public-share-gate">
        <div className="public-share-lock"><LockKeyhole size={21} /></div>
        <h2>Access your shared file</h2>
        <p>Enter the share password if one was configured by the owner.</p>
        <label>Share password<input autoFocus type="password" value={password} onChange={e => setPassword(e.target.value)} onKeyDown={e => { if (e.key === "Enter") unlock(); }} placeholder="Enter password" /></label>
        {err && <div className="public-share-error">{err}</div>}
        <button className="btn public-share-primary" onClick={unlock} disabled={loading}><KeyRound size={16} />{loading ? "Verifying access…" : "Open secure share"}</button>
      </section>}

      {data && <>
        {err && <div className="public-share-error">{err}</div>}
        <div className="public-share-permissions">
          <div><strong>Access granted</strong><span>Permissions set by the owner</span></div>
          <div className="public-share-permission-list">
            {permissionItems.map(([key, label, Icon]) => data.permissions?.[key] ? <span className="public-share-permission active" key={key}><Icon size={13}/>{label}</span> : null)}
          </div>
        </div>

        {folder && <section className="public-share-folder-gate">
          <div className="public-share-lock"><LogIn size={21} /></div>
          <h2>Sign in to access this folder</h2>
          <p>Folder sharing is available to registered SecureFile users. Sign in with your account to continue.</p>
          <Link className="btn public-share-primary" to={loginHref}><LogIn size={16}/> Sign in to SecureFile</Link>
          <small>Don't have an account? Contact the workspace owner for access.</small>
        </section>}

        {file && data.permissions?.view && <section className="public-share-preview-section">
          <div className="public-share-section-head"><div><p className="eyebrow">Viewer</p><h2>File preview</h2></div>{data.permissions?.download && <button className="btn small" onClick={download}><Download size={15}/> Download</button>}</div>
          <div className="public-share-preview">
            {contentLoading && <div className="public-share-loading"><span className="sf-spinner"/> Loading secure preview…</div>}
            {!contentLoading && contentUrl && (file.mimeType || "").startsWith("image/") && <img src={contentUrl} alt={file.name} />}
            {!contentLoading && contentUrl && (file.mimeType || "").includes("pdf") && <iframe title="Secure file preview" src={`${contentUrl}#toolbar=0&navpanes=0`} />}
            {!contentLoading && contentUrl && (file.mimeType || "").startsWith("text/") && <iframe title="Secure text preview" src={contentUrl} />}
            {!contentLoading && contentUrl && !((file.mimeType || "").startsWith("image/") || (file.mimeType || "").includes("pdf") || (file.mimeType || "").startsWith("text/")) && <div className="public-share-unavailable"><FileText size={28}/><strong>Preview is not available in this browser</strong><span>{typeLabel(file.mimeType)}</span>{data.permissions?.download && <button className="btn" onClick={download}><Download size={15}/> Download file</button>}</div>}
            {!contentLoading && !contentUrl && <div className="public-share-unavailable"><Eye size={28}/><strong>Preview unavailable</strong><span>The owner has allowed viewing, but the file preview could not be loaded.</span></div>}
          </div>
        </section>}

        {file && !data.permissions?.view && <section className="public-share-denied"><LockKeyhole size={24}/><strong>Viewing is not permitted</strong><span>The owner did not grant view access to this public share.</span></section>}
      </>}

      <footer className="public-share-footer"><span><ShieldCheck size={14}/> Protected by SecureFile permissions</span>{data?.permissions?.download ? <span>Download enabled</span> : <span>View only · Download disabled</span>}</footer>
    </main>
  </div>;
}
